# BudgetMate — Project Guide

## Project Overview
Persian RTL personal finance app with AI advisor. Full-stack: FastAPI backend + Next.js frontend.

## Architecture
```
budgetmate/
├── backend/          # FastAPI + SQLite + Alembic
│   ├── app/
│   │   ├── main.py   # App entry, router mounts
│   │   ├── models/   # SQLAlchemy models
│   │   ├── routers/  # API route handlers
│   │   ├── services/ # AI service (OpenAI planner/orchestrator)
│   │   └── core/     # Auth, config, seed, jalali
│   └── .env          # Secrets (JWT, AI provider)
└── frontend/         # Next.js 16 + Tailwind v4 + shadcn/ui
    └── src/
        ├── app/      # App Router pages
        ├── components/ui/  # shadcn-style components (written manually)
        ├── lib/      # api.ts, fmt.ts, utils.ts
        └── store/    # Zustand auth store
```

## Running

### Backend
```powershell
cd backend
python -m uvicorn app.main:app --reload --port 8000
```

### Frontend
```powershell
cd frontend
npm run dev
```

## Test Credentials
- User OTP phone: `09120000001`, code: `123456`
- Admin: username=`admin`, password=`5tgb%TGB`

## Key URLs
- Frontend: http://localhost:3000
- Backend API: http://localhost:8000/api/v1
- API Docs: http://localhost:8000/docs
- Admin panel: http://localhost:3000/admin

## Known Bugs Fixed
- **Pydantic v2 field/type name collision**: In `schemas/transaction.py`, the field `date: Optional[date]` caused Pydantic v2 to resolve the annotation as `NoneType` because the field name `date` shadowed the imported `datetime.date` type. Fixed by `from datetime import date as DateType` and using `DateType` in annotations. Any future schema field whose name matches its type import needs the same alias treatment.

## Important Notes
- Next.js 16 with React 19 and Tailwind CSS v4 (CSS-based config, not tailwind.config.ts)
- shadcn/ui init failed due to network (ECONNRESET), components written manually in src/components/ui/
- Zod v4 breaking changes: no `invalid_type_error`/`required_error`, use `z.number()` with `valueAsNumber: true` in react-hook-form register
- passlib incompatible with Python 3.13 — bcrypt used directly in backend
- AI service uses OpenAI only in the active chat/orchestrator path.
- jalaliday plugin used for Jalali/Shamsi calendar dates

## Authentication + Onboarding Flow (implemented)
New user path: `/login` → `/login/phone` → `/login/otp` → `/onboarding/profile` → `/onboarding/agreement` → `/onboarding/welcome` → `/chat`
Returning user path: `/login` → `/login/phone` → `/login/otp` → `/chat`

Route guards:
- `/onboarding/*` — requires token, redirects to `/chat` if `onboarding_completed=true`
- `/(app)/*` — requires token AND `onboarding_completed=true`, else redirects to `/onboarding/profile`

Auth store fields: `token`, `user`, `adminToken`, `needsProfile`, `onboardingCompleted`, `setOnboardingCompleted`

## New Endpoints (since original build)
- `GET  /api/v1/onboarding/status`
- `POST /api/v1/onboarding/profile`
- `POST /api/v1/onboarding/agreement`
- `POST /api/v1/onboarding/complete`
- `GET  /api/v1/iran/provinces` — 31 provinces
- `GET  /api/v1/iran/cities?province=X` — cities per province
- `POST /api/v1/chat/voice` — multipart audio, transcribes + replies

## Design System (Cleo-inspired)
- Background: `#f5f1eb` (warm cream)
- Primary dark: `#2d1812` (warm brown)
- Accent: `#10b981` (emerald)
- Buttons: `rounded-full`, `py-4`, full-width
- Headings: Vazirmatn 800, text-4xl
- Shared components: `PageTransition.tsx`, `OnboardingLayout.tsx`, `BgImageScreen.tsx`
- Animations: Framer Motion throughout

## AI Chat Pipeline (upgraded)
- `backend/app/services/ai.py` — `build_system_prompt(context, chat_mode)` with five sections: base persona, tone directive, user financial context, behavior rules, action spec.
- `backend/app/services/ai_actions.py` — `extract_actions`, `execute_action`, `process_ai_reply`. Strips ```json {...}``` action blocks from AI reply, executes them (create_goal / create_transaction / set_budget), appends Persian ✅/⚠️ confirmation lines.
- `/chat/message` and `/chat/stream` both run `process_ai_reply` before saving. Stream emits `event: complete` with canonical final text after raw streaming.
- `User.chat_mode` column (normal/roast/hype) — migration 004. Exposed in `UserOut`, accepted in `PATCH /users/me`.
- Profile page has a 3-pill chat mode selector that immediately PATCHes on click.
- Chat page SSE parser handles `event: complete` by replacing accumulated text with the canonical processed text.

## Income Range → Initial Budget Maximum Map
Initial onboarding budget uses the maximum value of the selected range, never the midpoint.

| range | initial monthly budget |
|-------|------------------------|
| lt10 | 10,000,000 |
| 10to20 | 20,000,000 |
| 20to40 | 40,000,000 |
| 40to80 | 80,000,000 |
| gt80 | 80,000,000 |

## Admin Panel (enhanced)
- **Auth isolation**: `api` 401 handler is path-aware — `/admin/*` routes redirect to `/admin`, user routes redirect to `/login`. `adminApi` has same path-aware logic.
- **DELETE `/api/v1/admin/users/{user_id}`**: cascade-deletes user + all related records (billing tokens, chat messages, transactions, budgets, goals, activity logs). Logs `admin_deleted_user` before deletion. Returns `{deleted: true, user_id}`.
- **GET `/api/v1/admin/users/{user_id}/chats`**: paginated chat history. Params: `page`, `page_size`. Response: `{items, page, page_size, total}`. Within each page messages are ASC (natural reading order).
- **Extended `UserOut`**: now includes `birthdate`, `agreement_accepted_at`, `agreement_version`, `onboarding_completed_at`.
- **User detail page** (`/admin/users/[id]`): two tabs — "اطلاعات کاربر" (full info table + block/unblock/delete/back buttons) and "گفت‌وگوها" (paginated chat timeline).
- **DeleteUserDialog** (`components/admin/DeleteUserDialog.tsx`): requires admin to type exact phone number before delete button enables.
- **Users list** (`/admin/users`): trash icon per row opens DeleteUserDialog; refreshes list after deletion.
- **Helpers**: `relativeTime(iso)` in `lib/fmt.ts`; `incomeRangeLabel`, `chatModeLabel` in `lib/labels.ts`. Badge `warning` variant added.

## What's Done
- [x] Backend: all models, routers, auth, AI service, seed data
- [x] Frontend: all pages, components, auth flow, charts, admin panel
- [x] Onboarding: full redesign — new login flow, onboarding pages, voice chat, route guards
- [x] Chat empty state: hero greeting (yellow smiley + name), suggested prompt chips, budget onboarding card, minimal header
- [x] AI chat improvements: behavior rules, tone modes, auto-execute actions from chat
- [x] AI action safety: no actions fired for advice/hypothetical questions; backend rejects transactions < 1000 toman, goals < 100k, budgets < 100k; failed actions logged silently (never shown to user)
- [x] AI chat memory: last 20 messages sent as history to AI provider on every /chat/message, /chat/stream, /chat/voice — AI no longer forgets prior turns
- [x] AI income context: monthly_income field on User (migration 005); set_income action saves exact income; income range used for range-based answers (e.g., "20% of 40-80M = 8-16M") with fallback to exact when saved
- [x] AI conversation rules: explicit rules to use prior answers, never re-ask answered questions, use range before asking for exact number
- [x] Admin panel: auth isolation, delete user endpoint + dialog, chat history endpoint + timeline, extended user detail with tabs

## What's Left
- [ ] Docker Compose (backend + frontend + nginx)
- [ ] README with setup instructions
- [ ] E2E testing
- [ ] PWA manifest
- [ ] Polish: loading states, error boundaries, Jalali date picker
